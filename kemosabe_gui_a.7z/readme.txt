Kemosabe v1.0, The Encryption Soskcs5 Proxy for Toranger V3 [Experiment]
[You can use it stand alone]

What is Kemosabe

The kemosabe is an encryption socks5 proxy. this component is for Toranger V3 experimental version.
you can use this software stand alone for now.

How to use kemosabe:
first of all you need at least .NET 3.5 installed in your system.
click Kemosabe_win to run kemosabe as a windows form program. you can see the buttons:

Run as Server
Run as Client
Stop All
Edit config file

now before you run kemosabe, you must config the config file first.
you can use edit config file button to open this file or you can open the file in any editor whatever you want
as you can see, the config file was formed by 3 options
[local], [sever] and [encryption_of_local]
the detail is:

[local] --> this option point to the local PC, you may use these settings in your own software as a proxy
local_ip=any      --> this ip means what software will use kemosabe as proxy that would connect to, 
                              you can put "127.0.0.1" as well, and if you had two or more net cards, 
                              set to "any" was good or you can point to another net card to set, something like: "127.0.0.3".
local_port=2048     --> this port means what software will use kemosabe as proxy that would connect to.
remote_port=1024  --> this port means that kemosabe client needs which kemosabe server port for connect.
remote_ip=61.x.x.x  --> this ip means that kemosabe server ip address that kemosabe client will connect to.

[server]   --> this option point to kemosabe server options
ip=any     --> this ip means which ip would be accept to this server, the "any" means any ip addresses.
port=1024   --> this port means server port, kemosabe client needs it.
max_clients=256  --> this option means how many kemosabe clients allowed to this kemosabe server.

[encryption_of_local]  --> this option is for [local] option, 
interface=default_encrypt.dll  --> you can change the DLL encryption interface if you had programmed it.
in=yes   --> this means local software to kemosabe client needs encrypt
out=yes  --> this means kemosabe client to kemosabe server needs encrypt. 
                   *if you use kemosabe server and client, YOU NEED TO ALLOW YES to "in" and "out", or both "NO"*
                   *if you use kemosabe client to connect to common socks5 server, YOU NEED ALLOW "out" to no*

to run kemosabe server, use kemosabe -s ,
to run client, use kemosabe -c

Ken J Gerty
5/21/2015