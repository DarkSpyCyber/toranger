
Kemosabe v2
the Socks5 proxy tool

please change kemosabe.conf in "bin" folder.

for the quick start, you can just change "remote ip", "local port" or "remote port" options.

and set your browser to 127.0.0.1:YOUR_LOCAL_PORT
the "remote_ip" is the server ip address which was your kemosabe service runs.

for server, you can just run server_run in Linux and server_run.bat in Windows Server.
and for the client, run client_run in Linux and client_run.bat in Windows system.

for Linux Users:
if your system has an error occured, such as: "libc.so.6: version `GLIBC_2.14' not found"

just run: install_glibc scripts to install GLIBC_2.14

have fun
Ken Joseph Gerty
Jun.24.2016
report bugs to ranger_machete@gmx.com . thanks.
